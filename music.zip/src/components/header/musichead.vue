<template>
  <div class="indexHead">
  <div class="musicHead" >
    <img src="./img/menu.png" alt="" @click="showInfo() "/>
    <div class="centerLog">
      <router-link to="/myMusic"><img :src="activity===0 ?  '../static/img/music.png': '../static/img/music2.png'"  @click="select(0)" /></router-link>
      <router-link to="/musicCenter"><img :src="activity===1 ?  '../static/img/musicLog.png': '../static/img/musicLog2.png'" @click="select(1)"  /></router-link>
      <router-link to="/soclai"><img :src="activity===2 ?  '../static/img/social.png': '../static/img/social2.png'" @click="select(2)" /></router-link>
    </div>
    <router-link to="/search"><img src="./img/search.png" alt=""/></router-link>
  </div>
    <myInfo :result="active" @on-result-change="onResultChange"></myInfo>
  </div>

</template>
<script type="text/ecmascript-6">
  import myInfo from '../myInfo/myInfo.vue'
  export default {
    data () {
      return {
        activity: 1,
        active: false
      }
    },
    methods: {
      select (activity) {
        this.activity = activity
      },
      onResultChange (val) {
        console.log('onResultChange方法接收子组建传过来的值 :' + val)
        this.active = val // ④外层调用组件方注册变更方法，将组件内的数据变更，同步到组件外的数据状态中
      },
      showInfo () {
        this.active = !this.active
      }
    },
    components: {
      myInfo
    }
  }
</script>
<style scoped>
.musicHead{
  display: flex;
  justify-content: space-between ;
  width: 7.2rem;
  height:.8rem;
  background: #e20000;
  position: fixed;
  z-index:9;
 }
  .musicHead img{
     width:.40rem;
     height:.40rem;
     margin:.2rem .32rem 0rem .32rem;

  }


</style>
