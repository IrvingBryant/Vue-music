<template>
 <div>我是音乐中心</div>
</template>
<script type="text/ecmascript-6">
    export default {}
</script>
<style>

</style>
