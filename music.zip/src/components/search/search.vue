<template>
  <div class="search">
  <div class="searchHead">
    <router-link to="/"><div class="searchExit"></div></router-link>
    <div class="searchInput"><input type="text" placeholder="请输入您想听的歌名" v-model="searchVal" @keyup.enter="onEnter"/></div>
  </div>
    <div class="searchBody">
      <div class="singerClassify">
        <p><img src="./img/singer.png" alt=""/>歌手分类<span>&gt;</span></p>
      </div>
       <div class="hotSearch">
         <p>热门搜索</p>
         <div class="searchContentArea" >
         <span class="hotsearchContent" v-for="item in searchContent">{{item}}</span>
         </div>
       </div>
      <div class="searchHistory"  v-show="ok">
            <p><img src="./img/history.png" alt=""><span>{{ inputVal }}</span><img src="./img/close2.png" alt="" @click="hide"   class="closeHistory"></p>
        </div>

    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  export default {
    data () {
      return {
        ok: false,
        inputVal: null, // 表示搜索的值的副本
        searchContent: ['你是不是我最疼爱的人', '寂静之空', '寂静之空', '寂静之空', '寂静之空'], // 表示热搜内容
        searchVal: ''// 搜索的值
      }
    },
    methods: {
      hide () {
        console.log('hide方法触发')
        this.ok = false
      },
      onEnter () {
        var url = '/soso/fcgi-bin/search_for_qq_cp?g_tk=792116527&uin=0&format=json&inCharset=utf-8&outCharset=utf-8&notice=0&platform=h5&needNewCode=1&w=' + this.inputVal + '&zhidaqu=1&catZhida=1&t=0&flag=1&ie=utf-8&sem=1&aggr=0&perpage=20&n=20&p=2&remoteplace=txt.mqq.all&_=1514358703016'
        if (this.searchVal.trim() !== '') {
          this.inputVal = this.searchVal
          this.ok = true
          axios.get(url)
            .then(function (response) {
              console.log(response)
              console.log(response.data.song)
            })
            .catch(function (err) {
              console.log(err)
            })
        }
      }
    }
  }
</script>
<style scoped>

  .searchBody{
    position: absolute;
    top:.8rem;
  }
  .search{
    background: #f2f4f5;
    height:12rem;
    width: 7.2rem;
  }
  .searchHead {
    height: .8rem;
    width: 7.2rem;
    background: #d33a31;
    position: fixed;
    z-index: 10;
    top: 0;
  }

  .searchExit {
    width: .4rem;
    height: .4rem;
    float: left;
    background-image: url("./img/searchExit.png");
    background-size: 100% 100%;
    margin: .2rem .3rem;
    margin-right: .4rem;
  }

  .searchInput input {
    width: 5.6rem;
    height: .6rem;
    background: none;
    outline: none;
    border: 0px;
    border-bottom: .01rem solid #edb0ad;
    margin-top: .06rem;
    color: #e0756e;
  }
  .searchInput input::-webkit-input-placeholder { /* WebKit browsers */
    color: #e0756e;
  }

  .searchInput input:-moz-placeholder { /* Mozilla Firefox 4 to 18 */
    color: #e0756e;
  }

  .searchInput input::-moz-placeholder { /* Mozilla Firefox 19+ */
    color: #e0756e;
  }

  .searchInput input:-ms-input-placeholder { /* Internet Explorer 10+ */
    color: #e0756e;
  }

  [data-dpr="1"] .searchInput input {
    font-size: 16px;
  }

  [data-dpr="2"] .searchInput input {
    font-size: 32px;
  }

  [data-dpr="3"] .searchInput input {
    font-size: 48px;
  }
  .singerClassify p img{
     width:.4rem;
     height:.4rem;
     position:relative;
     top:.1rem;
    margin-right: .16rem;
    display: inline-block;
  }
  .singerClassify{
    width:7.2rem;
    height:.6rem;
    border-bottom: .01rem solid #e8e9ea;
    text-align: center;
    line-height: .6rem;
    color: #616262;
  }
  .singerClassify p span{
    margin-left: .16rem;
    font-size: .24rem;
    position: relative;
    /*top:.03rem;*/
  }
  .hotSearch{
    height:3rem;

    border-bottom: 0.01rem solid #e5e7e8;
    width:5.72rem;
    padding:.6rem 1rem 1rem .48rem
  }
  [data-dpr="1"] .hotSearch p{
     font-size: 16px;
     color:#aaabac;
   }
  [data-dpr="2"] .hotSearch p{
    font-size: 32px;
    color:#aaabac;
  }
  [data-dpr="3"] .hotSearch p{
    font-size: 48px;
    color:#aaabac;
  }
  .searchContentArea{
     padding-top: .32rem;
     display:flex;
     flex-wrap: wrap;
    justify-content:flex-start;
  }
  .hotsearchContent{
    border:.01rem solid #ced0d0;
    border-radius: .2rem;
    padding:.1rem;
    margin-top: .16rem;
    text-align: center;
    color:#303131;
    margin-left: .16rem;
  }
  .searchHistory{
    width:7.2rem;
    height:.6rem;
    color:#303130;
    border-bottom: .01rem solid #e5e7e8;
    margin-top: .1rem;
  }
  .searchHistory img{
    width:.48rem;
    height:.48rem;
    vertical-align: middle;
    margin-top: -0.06rem;
    margin-left: .32rem;
    margin-right: .16rem;
  }
  .searchHistory span {
    line-height: .6rem;
    width:5rem;
    height:.6rem;
    display: inline-block;
  }
  .closeHistory{
    width:.48rem;
    height:.48rem;

  }

</style>
