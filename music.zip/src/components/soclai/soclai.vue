<template>
<div>我是社交组件模块</div>
</template>
<script type="text/ecmascript-6">
    export default {}
</script>
<style>

</style>
