<template>
  <div class="musicfooter">
    <div class="footerImg"></div>
    <div class="nameContent">
      <p class="musicName">好好学习</p>
      <p class="singer">sheyang</p>
    </div>
    <div class="btnAudio" id="btnaudio" @click="play()" v-bind:class="{stop:isopen}">
    <audio src="../../static/sing/music.mp3"    id="mp3Btn">
      Your browser does not support the audio tag.
    </audio>
    </div>
  </div>
</template>
<script type="text/ecmascript-6">
  export default {
    data () {
      return {
        isopen: false // 添加stop样式
      }
    },
    methods: {
      play () {
        var $mp3Btn = document.getElementById('mp3Btn')
        console.log('音频总时长:' + $mp3Btn.duration)
        if (this.isopen === true) {
          this.isopen = false
        } else {
          this.isopen = true
        }
        $mp3Btn.onended = function () {
          console.log('音频已播放完成')
        }
        if ($mp3Btn.paused) { // 如果当前状态是停止
          console.log('音频是暂停')
          $mp3Btn.play()
          console.log($mp3Btn.currentTime)
        } else {
          $mp3Btn.pause()
        }
      }
    },
    components: {
    }

  }
</script>
<style scoped>
  .musicfooter{
    width:7.2rem;
    height:.8rem;
    background: #ffffff;
    position: fixed;
    top:100%;
    margin-top: -.8rem;
  }
  .footerImg{
    width:.64rem;
    height:.64rem;
    float:left;
    background-image: url("./img/footerImg.jpg");
    background-size:100% 100% ;
    margin:.08rem .32rem  0 .16rem;
  }
  .nameContent{
    float: left;
    margin-top:.08rem;
  }
  .nameContent .musicName{
    font-size: .22rem
  }
  .singer{
    font-size: .20rem;
    color:#c2c3c4;
  }
  .btnAudio{
    position:absolute;
    left:6rem;
    top:.08rem;
    background-image: url("./img/yes.png") ;
    background-size:100% 100% ;
    width:.64rem;
    height:.64rem;
    border-radius: 50%;
}
  .musicfooter  .stop{
    background-image:url('./img/no.png');
  }
  #mp3Btn{
    width: 2rem;
    height:2rem;
    background: black;
  }

</style>
