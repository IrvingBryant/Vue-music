<template>
  <div class="main">
    <musichead></musichead>
    <router-view></router-view>
    <musicFooter></musicFooter>
  </div>
</template>
<script type="text/ecmascript-6">
  import musichead from '../header/musichead.vue'
  import musicFooter from '../footer/musicFooter.vue'
//  import myInfo from '../myinfo/myInfo.vue'
  export default {
    components: {
      musichead,
      musicFooter
    }
  }
</script>
<style>

</style>
