import Vue from 'vue'
import Router from 'vue-router'
import login from '../components/loginReg/login.vue'
import reg from '../components/loginReg/reg.vue'
import loginReg from '../components/loginReg/loginReg.vue'
// import musichead from '../components/header/musichead.vue'
import myMusic from '../components/myMusic/myMusic.vue'
import musicCenter from '../components/musicCenter/musicCenter.vue'
import soclai from '../components/soclai/soclai.vue'
import index from '../components/index/index.vue'
import search from '../components/search/search.vue'

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/login',
      component: login
    },
    {
      path: '/reg',
      component: reg
    },
    {
      path: '/loginReg',
      component: loginReg
    },
    {
      path: '/',
      name: 'index',
      component: index,
      children: [
        {path: '/myMusic', component: myMusic},
        {path: '/musicCenter', component: musicCenter},
        {path: '/soclai', component: soclai},
        {path: '/search', component: search}
      ]
    }
  ]
})
